package ast;


public class EFalse extends Exp{
	
	public EFalse()
	{
	  super();
	  
	} 
	
	public String toString() {
		return "false";
	}

}
