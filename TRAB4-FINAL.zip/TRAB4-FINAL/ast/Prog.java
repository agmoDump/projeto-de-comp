package ast;

import java.util.ArrayList;

public class Prog{
    public Main main;
    public ArrayList<Fun> fun;
    public Prog(Main main, ArrayList<Fun> fun)
    {
        this.main = main;
        this.fun = fun;
    }

    public String toString() {
		String bodyProg = this.main.toString() + "\n";

		for( Fun func : this.fun ) {
			bodyProg = bodyProg.concat( func.toString() + "\n" );
		}

		return bodyProg + "main();\n";
	}
}

