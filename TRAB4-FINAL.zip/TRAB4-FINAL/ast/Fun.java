package ast;

import java.util.ArrayList;

public class Fun{
	public String nome;
	public ArrayList<ParamFormalFun> params;
	public String retorno;
	public ArrayList<VarDecl> vars;
	public ArrayList<Comando> body;
	
	public Fun(String nome,ArrayList<ParamFormalFun> params, String retorno,ArrayList<VarDecl> vars,ArrayList<Comando> body)
	{
		this.nome = nome;
		this.params = params;
		this.retorno = retorno;
		this.vars = vars;
		this.body = body;
	}

	public String toString() {
		String bodyFuncao = "function " + this.nome + "(";

		if( !this.params.isEmpty() ) {
			bodyFuncao = bodyFuncao.concat( " " );

			for( ParamFormalFun param : this.params ) {
				bodyFuncao = bodyFuncao.concat( param.toString() + ", " );
			}

			bodyFuncao = bodyFuncao.substring( 0, bodyFuncao.length() - 2 );
			bodyFuncao = bodyFuncao.concat( " " );
		}

		bodyFuncao = bodyFuncao.concat( ") {\n" );

		for( VarDecl decl : this.vars ) {
			bodyFuncao = bodyFuncao.concat( decl.toString() );
		}

		for( Comando cmd : this.body ) {
			bodyFuncao = bodyFuncao.concat( cmd.toString() );
		}

		return bodyFuncao + "}\n";
	}
}
