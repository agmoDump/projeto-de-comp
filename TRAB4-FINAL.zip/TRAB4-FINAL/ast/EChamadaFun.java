package ast;

import java.util.ArrayList;

public class EChamadaFun extends Exp{
	public String fun;
	public ArrayList<Exp> args;
	
	public EChamadaFun(String fun, ArrayList<Exp> args)
	{
	  this.fun = fun;
	  this.args = args;
	} 

	public String toString() {
		String argsList = "(";

		if( !this.args.isEmpty() ) {
			argsList = argsList.concat( " " );

			for( Exp arg : this.args )
			{
				argsList = argsList.concat( arg.toString() ) + ", ";
			}

			argsList = argsList.substring( 0, argsList.length() - 2 );
			argsList = argsList.concat( " " );
		}

		return this.fun + argsList + ")";
	}

}
