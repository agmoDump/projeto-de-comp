package ast;


public class ETrue extends Exp{
	
	public ETrue()
	{
	  super();
	  
	} 

	public String toString() {
		return "true";
	}
}
