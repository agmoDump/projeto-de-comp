package ast;

import java.util.ArrayList;

public class CPrint extends Comando{
	//public int linha;
	public Exp exp;
	
	
	public CPrint(Exp exp)
	{
	  //this.linha = linha;
	  this.exp = exp;
	  
	} 

	public String toString() {
		return "console.log( " + this.exp.toString() + " );\n";
	}
}
