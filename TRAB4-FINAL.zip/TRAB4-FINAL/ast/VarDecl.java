package ast;

public class VarDecl{
   public String type;
   public String var;
   
   public VarDecl(String type,String var){
   	this.type = type;
   	this.var = var;
   }

	public String toString() {
		return "let " + this.var + ";\n";
	}
}
