function main() {
let testefloat;
let outro2float2;
let teste_bool;
let testevoid;
testefloat = 9.0;
outro2float2 = ( testefloat + 10.0 );
if( ( teste_bool == true ) ) {
teste_bool = false;
testevoid = prompt();
return testevoid;
}

while( ( MenorIgual( testefloat, 3.0 ) == true ) ) {
testefloat = ( testefloat / 2.0 );
}
console.log( ( testefloat + 5.5 ) );
TesteFunc();
}

function TesteFunc() {
console.log( ( 1.7 + 1.2 ) );
}

function MenorIgual( arg1, Arg_2 ) {
if( ( arg1 < Arg_2 ) ) {
return true;
}

if( ( arg1 > Arg_2 ) ) {
return false;
}

return true;
}

main();
